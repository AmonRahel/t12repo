//1. feladat
let eredmeny = KockaFelszin(2);
let eredmeny2 = KockaFelszin(3);
let eredmeny3 = KockaFelszin(5);
document.write(eredmeny +"<br>");
document.write(eredmeny2 + "<br>");
document.write(eredmeny3 + "<br>");

function KockaFelszin(a){
	let felszin = 6*(a*a);
    
    return felszin;
}

//2. feladat
let eredmeny4 =  KockaTerfogat(2);
let eredmeny5 = KockaTerfogat(3);
 let eredmeny6 = KockaTerfogat(5);
document.write(eredmeny4 + "<br>");
document.write(eredmeny5 + "<br>");
 document.write(eredmeny6 + "<br>");

function KockaTerfogat(a){
 let eredmeny=(a*a*a);
 return eredmeny;
}

//3. feladat
function PhErtek(vizsgaltErtek){
    if(vizsgaltErtek==7){
        document.write("A(z) " + vizsgaltErtek + " semleges. <br>");
    }
   else if(vizsgaltErtek>7){
        document.write("A(z) " + vizsgaltErtek + " lúgos. <br>");
    }
   else{
        document.write("A(z) " + vizsgaltErtek + " savas.<br>");
    }
  
}
PhErtek(9);
PhErtek(5.5);
PhErtek(7);

//4. feladat

let eredmeny7 = ElsoNSzamOsszege(3);
document.write(eredmeny7 + "<br>");
let eredmeny8 = ElsoNSzamOsszege(10);
document.write(eredmeny8 + "<br>");
let eredmeny9 = ElsoNSzamOsszege(21);
document.write(eredmeny9 + "<br>");

function ElsoNSzamOsszege(szamokMennyisege){
	let eredmeny = 0;
	for(let i=1; i<=szamokMennyisege; i++){
    	eredmeny += i;
    }
    return eredmeny;
}

//5. Feladat

let eredmeny10 = MaxParos([12,3,7,19,21]);
document.write(eredmeny10 + "<br>");
let eredmeny11 = MaxParos([28,14,2,42,69]);
document.write(eredmeny11 + "<br>");
let eredmeny12 = MaxParos([32,21,54,33,21]);
document.write(eredmeny12 + "<br>");

function MaxParos(vizsgaltTomb){
	let legnagyobbparos=0;
    for(let i=0;i<vizsgaltTomb.length;i++){
    	if(vizsgaltTomb[i] > legnagyobbparos && vizsgaltTomb[i]%2==0)
        {
        	legnagyobbparos = vizsgaltTomb[i];
        }
    }
    return legnagyobbparos;
}

//6. Feladat

let eredmeny13 = MaganHangzokSzama("Szeretem a programozás");
document.write(eredmeny13 + "<br>");
let eredmeny14 = MaganHangzokSzama("Géza kék az ég");
document.write(eredmeny14 + "<br>");
let eredmeny15 = MaganHangzokSzama("Répa, retek, mogyoró");
document.write(eredmeny15 + "<br>");
function MaganHangzokSzama(vizsgaltSzoveg){
	let maganhangzok=['a','á','e','é','i','í','o','ó','ö','ő','u','ú','ü','ű','A','Á','E','É','I','Í','O','Ó','Ö','Ő','U','Ú','Ü','Ű'];
    let eredmeny = 0;
    for(let i=0;i<vizsgaltSzoveg.length;i++)
    {
    	let szerepele = false;
    	for(let j=0;j<maganhangzok.length;j++)
        {
        	if(vizsgaltSzoveg[i] == maganhangzok[j])
            {
            	szerepele = true;
            }
        }
    	if(szerepele == true)
        {
        	eredmeny++;
        }

    }
    return eredmeny;
}

//7. feladat

let eredmeny16 = SzovegVisszafele("Szeretem a programozás");
document.write(eredmeny16  + "<br>");
let eredmeny17 = SzovegVisszafele("Géza kék az ég");
document.write(eredmeny17  + "<br>");
let eredmeny18 = SzovegVisszafele("Répa, retek, mogyoró");
document.write(eredmeny18 + "<br>");


function SzovegVisszafele(szoveg)
{
    let szovegvissza = "";
	for(let i=szoveg.length-1;i>=0;i--)
    {
    	szovegvissza += szoveg[i];
    }
    return szovegvissza;
}

//8. Feladat

let eredmeny19 = CegAtlagEletkor(Dolgozok);
document.write(eredmeny19);

function CegAtlagEletkor(vizsgaltObjektumTomb){

	let atlageletkor=0;
    let eletkorosszeg=0;
    for(let i=0;i<vizsgaltObjektumTomb.length;i++){
    	eletkorosszeg+=vizsgaltObjektumTomb[i].kor;
    }
    atlageletkor = eletkorosszeg / vizsgaltObjektumTomb.length;
    return Math.round(atlageletkor);

}

